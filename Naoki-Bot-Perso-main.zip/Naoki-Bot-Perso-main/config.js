module.exports = {
    app: {
        px: '+',
        token: '',
        owners: '843204602686078976',
        funny: '843204602686078976',
        color: '#FF0000',
        footer: 'sltcv ?',
        maxserver: '1',
        maxVol: '150',
        everyoneMention: false,
        hostedBy: true,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
}